/* 
 * File:   main.cpp
 * Author: Andrew Guzman
 * Created on September 7, 2022, 4:12 PM
 * Purpose:
 */

//System Libraries
#include <iostream>  //Input/output Library
using namespace std;

//User Libraries

//Global Constants
//Physics/Chemistry/Math/Conversion Higher Dimension Only

//Function Prototypes

//Program Execution Begins Here!!!

int main(int argc, char** argv) {
    //Set the Random Number Seed

    //Declare Variables

    //Initial Variables

    //Map the Inputs to the Outputs

    //Display the Inputs and Outputs
    cout<<"Hello World!"<<endl;

    //Exit the code
    return 0;
}

